﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;


namespace ServerApplication
{
    class Program
    {
        public static string IP;
        public static int Port;
        static List<Client> clientList = new List<Client>();
        
        static Socket serverSocket;


        static void Main(string[] args)
        {

            //绑定IP和端口
            BindIPAndPort();
            //
            while (true)
            {
                Socket clientSocket = serverSocket.Accept();
                Client client = new Client(clientSocket);
                clientList.Add(client);
                Console.WriteLine("一台主机进入连接");
            }
        }



        /// <summary>
        /// 广播数据
        /// </summary>
        public static void BroadcostMSG(string s)
        {
            List<Client> NotConnectedList = new List<Client>();
            foreach (var item in clientList)
            {
                if(item.IsConnected)
                {
                    item.SendMSG(s);
                }
                else
                {
                    NotConnectedList.Add(item);
                }
                
            }

            foreach (var item in NotConnectedList)
            {
                clientList.Remove(item);
            }


        }



        /// <summary>
        /// 绑定IP和端口
        /// </summary>
       public static void BindIPAndPort()
        {

            //创建一个serverSocket
            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            //声明IP和端口
            Console.WriteLine("输入IP地址：");
            IP = Console.ReadLine();
            string ipStr = IP;


            Console.WriteLine("请输入端口：");
            Port = int.Parse(Console.ReadLine());
            int port = Port;

            IPAddress serverIp = IPAddress.Parse(ipStr);
            EndPoint serverPoint = new IPEndPoint(serverIp, port);

            //socket和ip进行绑定
            serverSocket.Bind(serverPoint);

            //监听最大数为100
            serverSocket.Listen(100);
        }
    }
}
