﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Threading;

namespace ServerApplication
{
    class Client
    {
        public Socket clientSocket;
        Thread t;
        byte[] data = new byte[1024];

       // public string name="";



        public Client(Socket s)
        {
            clientSocket = s;
            t = new Thread(ReceiveMSG);
            t.Start();
        }



        /// <summary>
        /// 接收数据
        /// </summary>
        void ReceiveMSG()
        {
            while(true)
            {
                if (clientSocket.Poll(10,SelectMode.SelectRead))
                {
                    break;
                }
                   
                data = new byte[1024];
                int length = clientSocket.Receive(data);
                string message = Encoding.UTF8.GetString(data, 0, length);
                //TODO
                Program.BroadcostMSG(message);
                Console.WriteLine("收到消息：" + message);
            }
    
        }



        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="s"></param>
       public void SendMSG(string message)
        {
            byte[] data = Encoding.UTF8.GetBytes(message);
            clientSocket.Send(data);
        }

       

        public bool IsConnected
        {
            get { return clientSocket.Connected; }
        }

    }
}
