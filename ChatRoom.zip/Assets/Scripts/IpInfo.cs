﻿

public static class IpInfo {

    public static string name;
    public static string ipStr;
    public static int portStr;

}
